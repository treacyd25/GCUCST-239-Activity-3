package base;
public interface ShapeInterface {
	public int calculateArea();
}
