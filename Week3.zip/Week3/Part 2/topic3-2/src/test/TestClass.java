package test;
import base.ShapeBase;
import shape.Rectangle;
import shape.Triangle;

public class TestClass {
    private static void displayArea(ShapeBase shape) {
        System.out.println("This is a shape named " + shape.getName() + " with an area of " + shape.calculateArea());
    }

    public static void main(String[] args) {
        ShapeBase[] shapes = new ShapeBase[2];
        shapes[0] = new Rectangle("Rectangle",10, 200);
        shapes[1] = new Triangle("Triangle",10, 50);

        for (int x = 0; x<shapes.length;++x) {
            displayArea(shapes[x]);
        }
    }
}
