package app;

/**
 * The Person class represents a person with a first name and last name.
 * It provides methods to compare Person objects and to represent them as strings.
 */
public class Person implements PersonInterface, Comparable<Person>{
    private String firstName;
    private String lastName;
    private int age;
    private boolean running;
    
    /**
     * Constructs a new Person with the specified first name and last name.
     *
     * @param firstName the first name of the person
     * @param lastName the last name of the person
     * @param age the age of the person
     */
    public Person(String firstName, String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.running = false;
    }

    /**
     * Constructs a new Person by copying the details of another person.
     *
     * @param other the person to copy
     */
    public Person(Person other) {
        this.firstName = other.firstName;
        this.lastName = other.lastName;
    }

    /**
     * Compares this Person to the specified object. The result is true if and
     * only if the argument is not null and is a Person object that has the same
     * first name and last name as this object.
     *
     * @param other the object to compare this Person against
     * @return true if the given object represents a Person equivalent to this person, false otherwise
     */
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            System.out.println("I am here in the == this");
            return true;
        }
        if(other == null) {
            System.out.println("I am here in other == null");
            return false;
        }
        if (getClass() != other.getClass()) {
            System.out.println("I am here in getClass() != other.getClass()");
            return false;
        }
        Person person = (Person) other;
        return firstName.equals(person.firstName) && lastName.equals(person.lastName);
    }

    /**
     * Returns a string representation of this Person. The string consists of
     * the class name followed by the first name and last name of this person.
     *
     * @return a string representation of this person
     */
    @Override
    public String toString() {
        return "My class is " + getClass() + " " + firstName + " " + lastName;
    }
    
	@Override
	public void walk(){
		System.out.println("I am walking");
	}

	@Override
	public void run() {
		System.out.println("I am running");
		running = true;
	}

	@Override
	public boolean isRunning() {
		return running;
	}

	@Override
	public int compareTo(Person p) {
	    int ageComparison = Integer.compare(this.age, p.age);
	    if (ageComparison != 0) {
	        return ageComparison;
	    } else {
	        int lastNameComparison = this.lastName.compareTo(p.lastName);
	        if (lastNameComparison != 0) {
	            return lastNameComparison;
	        } else {
	            return this.firstName.compareTo(p.firstName);
	        }
	    }
	}

}
