package app;

import java.util.Arrays;

/**
 * The Test class is used to demonstrate the comparison of Person objects.
 * It creates instances of Person and compares them using both the == operator
 * and the equals() method. It also prints the Person objects using the
 * overridden toString() method.
 */
public class Test {
    public static void main(String[] args) {
        Person person1 = new Person("Justine", "Reha",30);
        Person person2 = new Person("Brianna", "Reha",25);
        Person person3 = new Person(person1);

        if(person1 == person2) {
            System.out.println("These persons are identical using ==");
        } else {
            System.out.println("These persons are not identical using ==");
        }
        if(person1.equals(person2)) {
            System.out.println("These persons are identical using equals()");
        } else {
            System.out.println("These persons are not identical using equals()");
        }
        if(person1.equals(person3)) {
            System.out.println("These copied person are identical using equals()");
        } else {
            System.out.println("These copied person are not identical using equals()");
        }

        System.out.println(person1);
        System.out.println(person2);
        System.out.println(person3);
        
        person1.walk();
        person1.run();
        System.out.println("Person 1 is running : " + person1.isRunning());
        person1.walk();
        System.out.println("Person 1 is running : " + person1.isRunning());

        person1.walk();
        
     // Create a bunch of Persons and compare them so they are sorted on Last Name
        Person[] persons = new Person [4];
        persons[0] = new Person("Justine", "Reha", 25);
        persons[1] = new Person("Brianna", "Reha" ,30);
        persons[2] = new Person("Mary", "Reha", 26);
        persons[3] = new Person("Mark", "Reha",23);
        Arrays.sort(persons);
        for(int x=0;x<4; x++ ) {
    	  System.out.println(persons[x]);
        }

        
     }
}
