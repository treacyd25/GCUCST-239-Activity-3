package app;

public interface PersonInterface {
	public void walk();
	public void run();
	public boolean isRunning();
}
