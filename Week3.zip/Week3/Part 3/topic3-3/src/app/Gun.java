package app;

/**
 * The Gun class is a specific type of Weapon that can fire with a specified power.
 * It also provides an overloaded method to fire the weapon with a default power level.
 */
public class Gun implements WeaponInterface  {
    /**
     * Fires the gun with the specified power.
     *
     * @param power the power level of the gun
     */
    @Override
    public void fireWeapon(int power) {
        System.out.println("In Gun.fireWeapon() with a power of " + power);
    }

    /**
     * Fires the gun with a default power level and calls the base class's fireWeapon method.
     */
    public void fireWeapon() {
        System.out.println("In Gun.fireWeapon()");
    }

    /**
     * Activates or deactivates the gun.
     *
     * @param enable true to activate the gun, false to deactivate
     */
    @Override
    public void activate(boolean enable) {
        System.out.println("In the Gun.activate() with an enable of " + enable);
    }
}
