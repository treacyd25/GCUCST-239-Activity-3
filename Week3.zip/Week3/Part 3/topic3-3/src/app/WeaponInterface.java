package app;

public interface WeaponInterface {
	public void fireWeapon();

	public void fireWeapon(int power);

	public void activate(boolean enable);
}