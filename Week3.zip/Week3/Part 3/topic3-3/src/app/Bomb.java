package app;

/**
 * The Bomb class is a specific type of Weapon that can fire with a specified power.
 * It also provides an overloaded method to fire the weapon with a default power level.
 */
public class Bomb implements WeaponInterface {
    /**
     * Fires the bomb with the specified power.
     *
     * @param power the power level of the bomb
     */
    @Override
    public void fireWeapon(int power) {
        System.out.println("In Bomb.fireWeapon() with a power of " + power);
    }

    /**
     * Fires the bomb with a default power level and calls the base class's fireWeapon method.
     */
    public void fireWeapon() {
        System.out.println("In Bomb.fireWeapon()");
    }

    /**
     * Activates or deactivates the bomb.
     *
     * @param enable true to activate the bomb, false to deactivate
     */
    @Override
    public void activate(boolean enable) {
        System.out.println("In the Bomb.activate() with an enable of " + enable);
    }
}
