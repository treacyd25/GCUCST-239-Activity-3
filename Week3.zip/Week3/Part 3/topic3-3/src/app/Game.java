package app;

/**
 * The Game class serves as the entry point for running the weapon simulation.
 * It creates instances of Bomb and Gun, activates them, and fires them with specified and default power levels.
 */
public class Game {
    /**
     * The main method executes the weapon simulation.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        // Initialize the weapons array
    	WeaponInterface[] weapons = new WeaponInterface[2];
        weapons[0] = new Bomb();
        weapons[1] = new Gun();

        // for all weapons fire them
        for (int x=0; x<weapons.length; x++) {
            fireWeapon(weapons[x]);
        }
    }
    
    private static void fireWeapon(WeaponInterface weapon){
    	 if(weapon instanceof Bomb)
    	    System.out.println("---------- I am a bomb");

    	  weapon.activate(true);
    	  weapon.fireWeapon(5);

    	}
}
